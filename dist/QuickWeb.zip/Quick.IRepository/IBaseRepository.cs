﻿/* ==============================================================================
* 命名空间：Quick.IRepository
* 类 名 称：IBaseRepository
* 创 建 者：Qing
* 创建时间：2018-11-29 22:39:40
* CLR 版本：4.0.30319.42000
* 保存的文件名：IBaseRepository
* 文件版本：V1.0.0.0
*
* 功能描述：N/A 
*
* 修改历史：
*
*
* ==============================================================================
*         CopyRight @ 班纳工作室 2018. All rights reserved
* ==============================================================================*/



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public partial interface IBaseRepository<T>
    {

    }
}
