﻿/* ==============================================================================
* 命名空间：Quick.Repository
* 类 名 称：BaseRepository
* 创 建 者：Qing
* 创建时间：2018-11-29 23:14:24
* CLR 版本：4.0.30319.42000
* 保存的文件名：BaseRepository
* 文件版本：V1.0.0.0
*
* 功能描述：N/A 
*
* 修改历史：
*
*
* ==============================================================================
*         CopyRight @ 班纳工作室 2018. All rights reserved
* ==============================================================================*/



using Masuit.Tools.Systems;
using Quick.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public partial class BaseRepository<T>
    {

    }
}
